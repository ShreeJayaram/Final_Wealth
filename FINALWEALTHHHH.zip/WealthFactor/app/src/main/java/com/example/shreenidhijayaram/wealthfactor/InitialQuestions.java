package com.example.shreenidhijayaram.wealthfactor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InitialQuestions extends AppCompatActivity {

    Button riskCalculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_initial_questions);

        Button nextPage = (Button) findViewById(R.id.nextbutton);
        final EditText A = (EditText) findViewById(R.id.age);
        final String k = A.getText().toString();
        nextPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                int result = R.string.age;
                Intent intent = new Intent(InitialQuestions.this, chart.class);
                intent.putExtra("age", 60);
                startActivity(intent);

            }
        }
        );


        final EditText I = (EditText) findViewById(R.id.income);
        final EditText F = (EditText) findViewById(R.id.family);
        final EditText result = (EditText) findViewById(R.id.risk);

        riskCalculator = (Button) findViewById(R.id.btn_Calculate);

        riskCalculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add your button function code here
                String st1 = I.getText().toString();
                String st2 = A.getText().toString();
                String st3 = F.getText().toString();

                if(TextUtils.isEmpty(st1))
                {
                    I.setError("Enter yearly income amount");
                    I.requestFocus();
                    return;


                }
                if(TextUtils.isEmpty(st2))
                {
                    A.setError("Enter your age");
                    A.requestFocus();
                    return;

                }
                if(TextUtils.isEmpty(st3))
                {
                    F.setError("Enter family size");
                    F.requestFocus();
                    return;

                }

                float i = Float.parseFloat(st1);
                float a = Float.parseFloat(st2);
                float f = Float.parseFloat(st3);

                float Income = calcIncome(i); //method not created
                float Age = calcAge(a);
                float Family = calcSize(f);
                float risk = calcFinalResult(Income, Age, Family);

                result.setText(String.valueOf(risk));



            }
        });
    }

    public float calcIncome(float i)
    {
        return (float) (i);

    }
    public float calcAge(float a)
    {
        return (float) (a);
    }
    public float calcSize(float f)
    {
        return (float) (f);
    }
    public float calcFinalResult(float Income, float Age, float Family)
    {
        return (float) ((Age * Family)/Income) * 20000;
    }



}

